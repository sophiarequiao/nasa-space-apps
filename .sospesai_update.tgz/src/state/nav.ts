import type { Screen } from "./AppState";

export const NAV: { id: Screen; label: string; hint: string }[] = [
  { id: "message", label: "Message", hint: "Know your crew: the daily check-in" },
  { id: "crew", label: "Crew", hint: "Everyone at a glance" },
  { id: "body", label: "Body", hint: "3D body with silent zones" },
  { id: "evolution", label: "Evolution", hint: "Before, during and after" },
  { id: "incident", label: "Incident", hint: "Know your options and your time" },
  { id: "resources", label: "Resources", hint: "Know your resources" },
  { id: "plan", label: "Plan", hint: "Adaptive monitoring and missions" },
  { id: "simulator", label: "Simulator", hint: "Profile + scenario + date" },
  { id: "learn", label: "Learn", hint: "Why each test matters" },
];
