// Always-visible mission selector: profile, mission day/date and the live Earth link.
import { useApp } from "../state/AppState";
import { NAV } from "../state/nav";
import { formatDuration } from "../engine/link";

export function Header() {
  const { data, profile, setProfileId, day, setDay, minDay, maxDay, date, dateOverride, setDateOverride, link, screen, setScreen, analogDelayS, setAnalogDelayS } = useApp();
  const owltMin = link.owltS / 60;
  return (
    <header className="header">
      <div className="header-top">
        <button className="brand" onClick={() => setScreen("message")} aria-label="SOSpesAI home">
          <svg viewBox="0 0 32 32" width="30" height="30" aria-hidden>
            <circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" strokeWidth="2" opacity=".5" />
            <path d="M5 17h6l3-7 4 13 3-6h6" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span>SOSpes<b>AI</b></span>
        </button>
        <p className="tagline">Know your crew. Know your resources. Know your options. Know your time.</p>
      </div>

      <div className="mission-bar">
        <label className="field">
          <span>Mission</span>
          <select value={profile.id} onChange={(e) => setProfileId(e.target.value)}>
            {data.profiles.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </label>
        {profile.link_model === "configurable" && (
          <label className="field">
            <span>Delay (s)</span>
            <input type="number" min={0} max={3600} value={analogDelayS} onChange={(e) => setAnalogDelayS(Number(e.target.value) || 0)} style={{ width: 80 }} />
          </label>
        )}
        <div className="field day-field">
          <span>Mission day</span>
          <div className="day-ctrl">
            <button onClick={() => setDay(day - 1)} aria-label="Previous day">−</button>
            <input type="range" min={minDay} max={maxDay} value={day} onChange={(e) => { setDateOverride(null); setDay(Number(e.target.value)); }} aria-label="Mission day" />
            <button onClick={() => setDay(day + 1)} aria-label="Next day">+</button>
            <b className="day-num">{day < 0 ? `L${day}` : `D${day}`}</b>
          </div>
        </div>
        <div className="field">
          <span>Date {dateOverride && <button className="linkbtn" onClick={() => setDateOverride(null)}>(simulated · reset)</button>}</span>
          <b>{date}</b>
        </div>
        <div className={`link-chip ${link.hasLink ? "up" : "down"}`} title={link.noLinkReason ?? "Link up"}>
          {link.hasLink ? (
            <>
              <span className="link-dot" /> Earth link · <b>{owltMin < 1 / 60 ? "real time" : formatDuration(owltMin)}</b> one way
              {!link.liveGuidance && <span className="muted"> · no live guidance</span>}
            </>
          ) : (
            <>
              <span className="link-dot" /> <b>NO LINK</b> · back in {formatDuration(link.waitMin)}
            </>
          )}
        </div>
      </div>

      <nav className="nav" aria-label="Screens">
        {NAV.map((n) => (
          <button key={n.id} className={screen === n.id ? "on" : ""} onClick={() => setScreen(n.id)} title={n.hint}>{n.label}</button>
        ))}
      </nav>
    </header>
  );
}
