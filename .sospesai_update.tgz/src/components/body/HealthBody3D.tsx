// 3D health body. Reuses the team's working GLB viewer approach (src/lib/anatomy-viewer)
// and paints each health region with its status colour: green, amber, red, or grey stripes
// for "silent" zones with no recent data.
import { Canvas, type ThreeEvent } from "@react-three/fiber";
import { OrbitControls, useGLTF } from "@react-three/drei";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import type { RegionId, Status } from "../../types";

export const SPATIAL_REGIONS: RegionId[] = ["brain", "eyes", "neck", "heart", "lungs", "kidneys", "musculoskeletal"];

/**
 * Map a point in model space to a health region. The model faces +x, y is up and
 * the body's left side is -z. Calibrated on the bundled GLB (head above y = 0.376).
 */
export function regionFromPoint(x: number, y: number, z: number): RegionId {
  const az = Math.abs(z);
  if (y > 0.376) {
    if (y > 0.416 && y < 0.452 && x > 0.028 && az < 0.042) return "eyes";
    return "brain";
  }
  if (y > 0.32) return az < 0.062 ? "neck" : "musculoskeletal";
  if (y > 0.215) {
    if (az > 0.098) return "musculoskeletal";
    // heart: an ellipse on the front of the chest, slightly to the body's left (-z)
    if (x > 0.0 && ((y - 0.268) / 0.038) ** 2 + ((z + 0.03) / 0.036) ** 2 < 1) return "heart";
    return "lungs";
  }
  if (y > 0.1) {
    if (az > 0.1) return "musculoskeletal";
    return "kidneys";
  }
  return "musculoskeletal";
}

const REGION_INDEX: RegionId[] = ["brain", "eyes", "neck", "heart", "lungs", "kidneys", "musculoskeletal"];

export const STATUS_COLOR: Record<Status, string> = {
  green: "#2fb36b",
  amber: "#f0a020",
  red: "#e5484d",
  silent: "#8a93a6",
};
const STRIPE_DARK = new THREE.Color("#5d6577");

interface BodyProps {
  modelUrl: string;
  regionStatus: Partial<Record<RegionId, Status>>;
  selected: RegionId | null;
  onSelect?: (r: RegionId) => void;
  interactive?: boolean;
}

function BodyMesh({ modelUrl, regionStatus, selected, onSelect, interactive = true }: BodyProps) {
  const { scene } = useGLTF(modelUrl);
  const modelRef = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState<RegionId | null>(null);

  // Clone once, convert to non-indexed geometry with a per-vertex colour and a per-vertex region id.
  const prepared = useMemo(() => {
    const clone = scene.clone(true);
    const meshes: { mesh: THREE.Mesh; region: Uint8Array; stripe: Uint8Array }[] = [];
    clone.updateMatrixWorld(true);
    clone.traverse((child) => {
      if (!(child instanceof THREE.Mesh)) return;
      let geometry = child.geometry.clone() as THREE.BufferGeometry;
      if (geometry.index) geometry = geometry.toNonIndexed();
      const pos = geometry.getAttribute("position");
      const colors = new Float32Array(pos.count * 3);
      geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
      const region = new Uint8Array(pos.count);
      const stripe = new Uint8Array(pos.count);
      const p = new THREE.Vector3();
      for (let i = 0; i < pos.count; i += 3) {
        p.set(
          (pos.getX(i) + pos.getX(i + 1) + pos.getX(i + 2)) / 3,
          (pos.getY(i) + pos.getY(i + 1) + pos.getY(i + 2)) / 3,
          (pos.getZ(i) + pos.getZ(i + 1) + pos.getZ(i + 2)) / 3,
        );
        p.applyMatrix4(child.matrixWorld);
        const r = REGION_INDEX.indexOf(regionFromPoint(p.x, p.y, p.z));
        const st = Math.floor((p.y + p.z * 0.6) * 90) % 2 === 0 ? 1 : 0; // diagonal stripes
        region[i] = region[i + 1] = region[i + 2] = r;
        stripe[i] = stripe[i + 1] = stripe[i + 2] = st;
      }
      geometry.computeVertexNormals();
      child.geometry = geometry;
      child.material = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.55, metalness: 0.05, vertexColors: true });
      meshes.push({ mesh: child, region, stripe });
    });
    return { clone, meshes };
  }, [scene]);

  // Repaint whenever statuses, selection or hover change.
  useEffect(() => {
    const cache = new Map<string, THREE.Color>();
    const colorFor = (r: RegionId, stripe: number): THREE.Color => {
      const s = regionStatus[r] ?? "silent";
      const key = `${r}|${s}|${stripe}|${selected === r}|${hovered === r}|${selected !== null}`;
      let c = cache.get(key);
      if (c) return c;
      c = s === "silent" && stripe ? STRIPE_DARK.clone() : new THREE.Color(STATUS_COLOR[s]);
      if (hovered === r) c.lerp(new THREE.Color("#ffffff"), 0.35);
      else if (selected && selected !== r) c.lerp(new THREE.Color("#1a2236"), 0.45);
      else if (selected === r) c.lerp(new THREE.Color("#ffffff"), 0.15);
      cache.set(key, c);
      return c;
    };
    for (const { mesh, region, stripe } of prepared.meshes) {
      const colors = mesh.geometry.getAttribute("color") as THREE.BufferAttribute;
      for (let i = 0; i < region.length; i++) {
        const c = colorFor(REGION_INDEX[region[i]], stripe[i]);
        colors.setXYZ(i, c.r, c.g, c.b);
      }
      colors.needsUpdate = true;
    }
  }, [prepared, regionStatus, selected, hovered]);

  const pick = (e: ThreeEvent<PointerEvent | MouseEvent>): RegionId | null => {
    if (!modelRef.current || !e.point) return null;
    const local = modelRef.current.worldToLocal(e.point.clone());
    return regionFromPoint(local.x, local.y, local.z);
  };

  return (
    <group position={[0, -0.06, 0]} scale={[2.0, 2.0, 2.0]}>
      <group ref={modelRef} rotation={[0, -Math.PI / 2, 0]}>
        <primitive
          object={prepared.clone}
          onClick={interactive ? (e: ThreeEvent<MouseEvent>) => { e.stopPropagation(); const r = pick(e); if (r) onSelect?.(r); } : undefined}
          onPointerMove={interactive ? (e: ThreeEvent<PointerEvent>) => { const r = pick(e); if (r !== hovered) setHovered(r); document.body.style.cursor = "pointer"; } : undefined}
          onPointerOut={interactive ? () => { setHovered(null); document.body.style.cursor = "default"; } : undefined}
        />
      </group>
    </group>
  );
}

export interface HealthBody3DProps extends BodyProps {
  height?: number | string;
  autoRotate?: boolean;
}

export function HealthBody3D({ height = 520, autoRotate = false, ...props }: HealthBody3DProps) {
  return (
    <div className="body3d" style={{ height }}>
      <Canvas camera={{ position: [0, 0.05, 2.35], fov: 45, near: 0.05, far: 100 }} gl={{ antialias: true, preserveDrawingBuffer: true }} dpr={[1, 2]}>
        <ambientLight intensity={0.75} />
        <directionalLight position={[5, 5, 5]} intensity={1.1} />
        <directionalLight position={[-5, 4, -5]} intensity={0.5} />
        <Suspense fallback={null}>
          <BodyMesh {...props} />
        </Suspense>
        <OrbitControls enablePan={false} enableZoom={false} minPolarAngle={Math.PI / 2} maxPolarAngle={Math.PI / 2} autoRotate={autoRotate} autoRotateSpeed={1.2} />
      </Canvas>
    </div>
  );
}

useGLTF.preload(`${import.meta.env.BASE_URL}geometries/human_body.glb`);
